-- CONSULTAR LOS TERCEROS Y SU FECHA DE ULTIMO PAGO Y PROXIMO PAGO
SELECT TOP 50 COD_EMPRESA,NOM_EMPRESA,ULT_PAGO,PROX_PAGO FROM GTSFBDB..PTMRG WHERE COD_EMPRESA='64545222'
                                                                         OR COD_EMPRESA='6526221'
                                                                         OR COD_EMPRESA='5145145'
                                                                         OR COD_EMPRESA='5455125'

-- CONSULTAR LOS PAGOS QUE PERTENECEN AL TERCERO
SELECT COD_EMPRESA, COD_PAGO,NOM_PAGO FROM GTSFBDB..PTMPG WHERE (COD_EMPRESA='64545222'
                                                             OR COD_EMPRESA='6526221'
                                                             OR COD_EMPRESA='5145145'
                                                             OR COD_EMPRESA='5455125')
                                                             AND ESTADO='A';
-- VERIFICAR LOS MOVIEMTOS DE LAS TRANSACCIONES QUE ESTAN DE LADO DE PORTAL FINANCIERO, ESTAS SE TIENE QUE COMPARAR CON LO QUE ESTA EN DBPAGOS
SELECT TOP 10 TRDIAIDENTITY,SCO_DOCUM,DCO_PAGO,(SELECT DATEADD (day, FECHA_REL, '01/01/1957'))as 'FECHA PAGO',FECHA_REL,SVA_EFECTIVO,ESTADO FROM GTSFBDB..TRDIA
                                                                                                                                      WHERE TRDIAIDENTITY='1404573587'
                                                                                                                                         OR TRDIAIDENTITY='1404573589'
                                                                                                                                         OR TRDIAIDENTITY='1404325125'
                                                                                                                                         OR TRDIAIDENTITY='1404326379'
                                                                                                                                         OR TRDIAIDENTITY='1404573611'
                                                                                                                                         OR TRDIAIDENTITY='1404552257'
                                                                                                                                         OR TRDIAIDENTITY='1404550733'
                                                                                                                                         OR TRDIAIDENTITY='1404550734'
                                                                                                                                         ORDER BY DCO_PAGO;





-- CONSULTAR LOS PAGOS DE DB_PAGOS
SELECT TOP 50 ID,DOCUMENTO,TIPO_PAGO,VALOR,EFECTIVO,FECHA_INGRESO FROM DB_PAGOS.dbo.TBL_PAGO WHERE ID='205313299'
                                                                                                OR ID='205313300'
                                                                                                OR ID='205313301'
                                                                                                OR ID='205313302'
                                                                                                OR ID='205313302'
                                                                                                OR ID='205313303'
                                                                                                OR ID='205313304'
                                                                                                OR ID='205313305'
                                                                                                OR ID='205313306' ORDER BY TIPO_PAGO;



-- ESTA CONSULTA EJECUTA EL MIDDLEWARE, SE LE PAGA EL CODIGO DE PAGO Y EL RANGO EN QUE SE QUIERE VER CUANTAS TRANSACCIONES Y EL MONTO DE LAS SUMAS DE LAS TRANSACCIONES
SELECT TOP 100 COUNT(*) AS 'Transacciones',SUM (EFECTIVO) as 'Valor Total' FROM dbo.TBL_PAGO WHERE TIPO_PAGO=3333 and
				FECHA_INGRESO >='2024-02-10 00:00:00:000' AND FECHA_INGRESO <='2024-02-13 23:59:59:999';



SELECT TOP 100 COUNT(*) AS 'Transacciones',SUM (EFECTIVO) as 'Valor Total' FROM dbo.TBL_PAGO WHERE TIPO_PAGO=88 and
				FECHA_INGRESO >='2024-04-09 00:00:00:000' AND FECHA_INGRESO <='2024-04-10 23:59:59:999';

SELECT TOP 100 COUNT(*) AS 'Transacciones',SUM (EFECTIVO) as 'Valor Total' FROM dbo.TBL_PAGO WHERE TIPO_PAGO=54 and
				FECHA_INGRESO >='2024-03-31 00:00:00:000' AND FECHA_INGRESO <='2024-04-03 23:59:59:999';

--6542.0720
--1320.50

-- 7862.57

SELECT * FROM PTMRG where PROX_PAGO = '31012024';
SELECT * FROM PTXMO

SELECT TOP 10 DCO_IDENT,NOM_EMPRESA, DCO_TIPO_RE,SALDO_PORTAL,MONTO_PAT,DIFERENCIA, (SELECT DATEADD (day, FE_CUADRE , '01/01/1957'))as FECHACUADRE,
              (SELECT DATEADD (day, TFE_RELDESDE , '01/01/1957'))as FECHADESDE, (SELECT DATEADD (day, TFE_RELHASTA, '01/01/1957'))as FECHAHASTA,DCO_ESTLIQ,DCO_ESTCCO,DCO_ESTADO FROM dbo.PTXMO

SELECT * FROM PTMRG